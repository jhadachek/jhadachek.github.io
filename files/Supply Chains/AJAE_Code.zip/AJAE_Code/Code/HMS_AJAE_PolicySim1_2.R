#Define preliminary structural parameters
f=0.3
g=0.95
gamma=1-g
c=(1-f)/((N)^gamma)

#Simulation for processor entry and market power policy considerations
simulation<-function(psi=1, xi=0.1,omega=0, eta = 0.7, epsilon=1, theta=0.1, N=40,n=1, cap=0){
set.seed(12345)
  
#Naming the types of distributions
##Here: sigma (demand)~halfnorm, mu (production)~ halfnorm, rho (shutdowns)~binom
  
distTypes<-c("halfnorm","halfnorm", "binom")
N<-round(N_base*n, digits=0)


#Specify the correlation between variables. 
#Elements correspond to the correlations: c([1,2], [1,3], [1,4], [1,5], [2,3], etc.)
#Three shock parameters, but can be expanded if needed. 
myCop <- normalCopula(param=c(psi*0.25,psi*-0.5, psi*0.1),
                      dim = 3, dispstr = "un")

#Provides the inputs for multivariate distributions. We supply our distributions to the margins function
#parmsMargins lists inputs for distribution specific parameters. i.e. theta belongs to half norm
myMvd <- mvdc(copula=myCop,
              margins=distTypes,
              paramMargins=list(list(theta=2),#First, the halfnormal demand shock
                                list(theta=10),#This is the production shock distrubution
                                list(N, prob=0.75)))#Then the shutdowns shock.
                                
                        
draws<-data.frame(rMvdc(100000, myMvd))#100000 draws or shocks
colnames(draws)<-c("demand", "supply", "processor")#Name each type of shock

Nt<-draws$processor#Post Shutdown number of processors


#####Inputs######

eta=0.7
epsilon=1
alpha = 1/eta
f=0.30
beta = f/epsilon
a=1+alpha
b=f-beta

# cost with economies of scale penalty with N
cw=c*N^gamma

#Incorporate Shocks
a=a+draws$demand
b=b+draws$supply

#Competitive Equilibrium
Qc<-(a-b-cw)/(alpha+beta*N/Nt)
Qci<-(a-b-cw)/(n*alpha+beta)


#Update Beta
beta<-beta*N/Nt
#Oligopoly,Oligopsony Equilibrium
Qoo_flex<-(a*(1-xi/eta)-b*(1+theta/epsilon)-cw)/(alpha*(1-xi/eta)+(beta)*(1+theta/epsilon))

#Compute equilibrium outcomes
Qoo<-Qoo_flex
Pwoo<-a-alpha*Qoo
Pfoo<-b+beta*Qoo


#Welfare
CS<-(a-Pwoo)*Qoo/2
PS<-(Pfoo-b)*Qoo/2
PI<-(Pwoo-Pfoo-cw)*(Qoo)

return(data.frame(avg_Qoo=mean(Qoo), 
                  sd_Qoo=sd(Qoo)/mean(Qoo),
                  cw=mean(cw),
                  beta=mean(beta, na.rm=T),
                  xi=mean(xi),
                  N=mean(N),
                  avg_Pfoo=mean(Pfoo, na.rm=TRUE),
                  sd_pfoo=sd(Pfoo, na.rm=T)/mean(Pfoo, na.rm=T),
                  avg_Pwoo=mean(Pwoo, na.rm=T),
                  sd_Pwoo=sd(Pwoo, na.rm=T)/mean(Pwoo, na.rm=T),
                  sd_CS=sd(CS, na.rm=T)/mean(CS, na.rm=T),
                  avg_CS=mean(CS, na.rm=T),
                  avg_PS=mean(PS, na.rm=T),
                  sd_PS=sd(PS, na.rm=T)/mean(PS, na.rm=T),
                  avg_PI=mean(PI, na.rm=T),
                  sd_PI=sd(PI)/mean(PI)                  ))

}


##############Simulate Increasing Market Power: Figure 4 #################################

concentration<-as.vector(seq(0.3,0,-0.01))
N_base<-40


both<-(mapply(simulation,psi=1, theta=concentration, xi=concentration, n=1,N=40, SIMPLIFY = FALSE))%>%
  bind_rows()%>%
    mutate(diff_sd_CS=(sd_CS-sd_CS[1])/sd_CS[1],
           diff_sd_PS=(sd_PS-sd_PS[1])/sd_PS[1],
           diff_sd_PI=(sd_PI -sd_PI[1])/sd_PI[1],
           diff_CS=(avg_CS-avg_CS[1])/avg_CS[1],
           diff_PS=(avg_PS-avg_PS[1])/avg_PS[1],
           diff_PI=(avg_PI-avg_PI[1])/avg_PI[1])


share<-ggplot(both)+
    geom_smooth(aes(concentration, diff_PS*100, color="PS"), size=1.25)+
    geom_smooth(aes(concentration, diff_CS*100, color="CS"), size=1.25)+
    geom_smooth(aes(concentration, diff_PI*100, color="Processor Profit"), size=1.25)+
    ylab("% Change in Surplus")+
    xlab(expression(xi~ "=" ~ theta))+
    ylim(-200,250)+
    geom_hline(yintercept=0, lty="dashed")+
    scale_x_reverse()+
    scale_color_manual("Surplus Share", values=c("PS"="orange", "CS"="dark green", "Processor Profit"="dark blue"))+
    theme_minimal()




sd<-ggplot(both)+
  geom_smooth(aes(concentration, diff_sd_PS*100, color="PS"), size=1.25, se=F)+
  geom_smooth(aes(concentration, diff_sd_CS*100, color="CS"), size=1.25, se=F)+
  geom_line(aes(concentration, diff_sd_PI*100, color="Processor Profit"), size=1.25, se=F)+
  ylab("% Change in the Coefficient of Variation")+
  xlab(expression(xi~ "=" ~ theta))+
  ylim(-50,50)+
  scale_x_reverse()+
  geom_hline(yintercept=0, lty="dashed")+
  scale_color_manual("Surplus", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue"))+
  theme_minimal()


ggarrange(sd, share, common.legend = TRUE, legend="top")
ggsave("Output/Figure4.png", scale = 5)

###################Simulate Increasing number of processors##########################
#Sequentially increasing the number of processors for nearly competitive markets
n<-as.vector(seq(10,13, 1))
c=(1-f)/((N[1])^gamma)# Updates c for every baseline N
N_base<-N/n[1]



N_sim0<-(mapply(simulation,n=n,xi=1/n, theta=1/n, SIMPLIFY = FALSE))%>%
  bind_rows()%>%
    mutate(diff_sd_CS=(sd_CS-sd_CS[1])/sd_CS[1],
           diff_sd_PS=(sd_PS-sd_PS[1])/sd_PS[1],
           diff_sd_PI=(sd_PI -sd_PI[1])/sd_PI[1],
           diff_CS=(avg_CS-avg_CS[1])/avg_CS[1],
           diff_PS=(avg_PS-avg_PS[1])/avg_PS[1],
           diff_PI=(avg_PI-avg_PI[1])/avg_PI[1])




N_sd0<-ggplot(N_sim0)+geom_line(aes(n,diff_sd_CS*100, color ="CS"), size=1.5, se=FALSE)+
  geom_line(aes(n, diff_sd_PS*100, color="PS"), size=1.25)+
  geom_line(aes(n, diff_sd_PI*100, color="Processor Profit"), size=1.25)+
  ylab("% Change in the Coefficient of Variation")+xlab("")+
  #geom_label(aes(x=40, y=0.9),label=expression(xi~ "=" ~ theta ~"=0"),size=10)+
  scale_color_manual("", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue"))+
  ylim(-30,30)+
  geom_hline(yintercept=0, lty="dashed")+
  theme_minimal()+
    theme(legend.position = 'top',
          legend.text =element_text(size=18))

N_avg0<-ggplot(N_sim0)+geom_line(aes(n,diff_CS*100, color ="CS"), size=1.25)+
  geom_line(aes(n, diff_PS*100, color="PS"), size=1.25)+
  geom_line(aes(n, diff_PI*100, color="Processor Profit"), size=1.25)+
  #geom_smooth(aes(N, share_dwl, color="DWL"))+
  ylab("% Change in Surplus")+xlab("")+
  scale_color_manual("", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue", "DWL"="dark red"))+
  ylim(-30,30)+
  geom_hline(yintercept = 0, lty="dashed")+
  theme_minimal()+
    theme(legend.position = 'top',
          legend.text =element_text(size=18))

processors0<-ggarrange(N_sd0,N_avg0,common.legend = TRUE, nrow=1, ncol=2,legend="top")
annotate_figure(processors0, 
                bottom="Number of Processing Firms")
ggsave("Output/Figure5a.png", scale = 5)


#Moderate market power under Cournot competition. 
n<-as.vector(seq(6,9, 1))
c=(1-f)/((N[1])^gamma)
N_base<-N/n[1]

N_sim15<-(mapply(simulation,n=n,xi=1/n, theta=1/n, SIMPLIFY = FALSE))%>%
    bind_rows()%>%
    mutate(diff_sd_CS=(sd_CS-sd_CS[1])/sd_CS[1],
           diff_sd_PS=(sd_PS-sd_PS[1])/sd_PS[1],
           diff_sd_PI=(sd_PI -sd_PI[1])/sd_PI[1],
           diff_CS=(avg_CS-avg_CS[1])/avg_CS[1],
           diff_PS=(avg_PS-avg_PS[1])/avg_PS[1],
           diff_PI=(avg_PI-avg_PI[1])/avg_PI[1])





N_sd15<-ggplot(N_sim15)+geom_line(aes(n,diff_sd_CS*100, color ="CS"), size=1.5)+
  geom_line(aes(n, diff_sd_PS*100, color="PS"), size=1.25)+
  geom_line(aes(n, diff_sd_PI*100, color="Processor Profit"), size=1.25)+
  ylab("% Change in the Coefficient of Variation")+xlab("")+
  scale_color_manual("", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue"))+
  ylim(-32,30)+
  geom_hline(yintercept=0, lty="dashed")+
  theme_minimal()+
    theme(legend.position = 'top',
          legend.text =element_text(size=18))

N_avg15<-ggplot(N_sim15)+geom_line(aes(n,diff_CS*100, color ="CS"), size=1.5)+
  geom_line(aes(n, diff_PS*100, color="PS"), size=1.25)+
  geom_line(aes(n, diff_PI*100, color="Processor Profit"), size=1.25)+
  ylab("% Change in Surplus")+xlab("")+
  geom_hline(yintercept=0, lty="dashed")+
  theme_minimal()+
  scale_color_manual("", values=c("PS"="orange", "CS"="dark green", "Processor Profit"="dark blue", "DWL"="dark red"))+
  ylim(-32,30)+
    theme(legend.position = 'top',
          legend.text =element_text(size=18))

processors15<-ggarrange(N_sd15,N_avg15,common.legend = TRUE, nrow=1, ncol=2,legend="top")
annotate_figure(processors15, 
                bottom="Number of Processing Firms")
ggsave("Output/Figure5b.png", scale = 5)


#High market power
n<-as.vector(seq(3,5, 1))
c=(1-f)/((N[1])^gamma)
N_base<-N/n[1]

N_sim30<-(mapply(simulation, n=n,xi=1/n, theta=1/n, SIMPLIFY = FALSE))%>%
    bind_rows()%>%
    mutate(diff_sd_CS=(sd_CS-sd_CS[1])/sd_CS[1],
           diff_sd_PS=(sd_PS-sd_PS[1])/sd_PS[1],
           diff_sd_PI=(sd_PI -sd_PI[1])/sd_PI[1],
           diff_CS=(avg_CS-avg_CS[1])/avg_CS[1],
           diff_PS=(avg_PS-avg_PS[1])/avg_PS[1],
           diff_PI=(avg_PI-avg_PI[1])/avg_PI[1])

N_sd30<-ggplot(N_sim30)+geom_line(aes(n,diff_sd_CS*100, color ="CS"), size=1.5)+
  geom_line(aes(n, diff_sd_PS*100, color="PS"), size=1.25)+
  geom_line(aes(n, diff_sd_PI*100, color="Processor Profit"), size=1.25)+
  ylab("% Change in the Coefficient of Variation")+xlab("")+
  theme_minimal()+
  scale_x_continuous(breaks=c(3,4,5))+
  geom_hline(yintercept=0, lty="dashed")+
  scale_color_manual("", values=c("PS"="orange", "CS"="dark green", "Processor Profit"="dark blue"))+
  ylim(-120,135)+
  theme_minimal()+
  theme(legend.position = 'top',
        legend.text =element_text(size=18))


N_avg30<-ggplot(N_sim30)+geom_line(aes(n,diff_CS*100, color ="CS"), size=1.5)+
  geom_line(aes(n, diff_PS*100, color="PS"), size=1.25)+
  geom_line(aes(n, diff_PI*100, color="Processor Profit"), size=1.25)+
  geom_hline(yintercept=0, lty="dashed")+
  scale_x_continuous(breaks=c(3,4,5))+
  ylab("% Change in Surplus")+xlab("")+
  theme(legend.position = 'top')+
  scale_color_manual("", values=c("PS"="orange", "CS"="dark green","Processor Profit"="dark blue", "DWL"="dark red"))+
  ylim(-120,135)+
  theme_minimal()+
  theme(legend.position = 'top',
          legend.text =element_text(size=18))




processors30<-ggarrange(N_sd30,N_avg30,common.legend = TRUE, nrow=1, ncol=2,legend="top")
annotate_figure(processors30, 
                bottom="Number of Processing Firms")
ggsave("Output/Figure5c.png", scale = 5)


########################Appendix Figure#########################

#Here we fix market power in each simulation, independent of n
n<-as.vector(seq(10,13, 1))
c=(1-f)/((N[1])^gamma)# Updates C for every baseline N
N_base<-N/n[1]



N_sim0<-(mapply(simulation,n=n,xi=0, theta=0, SIMPLIFY = FALSE))%>%
  bind_rows()%>%
  mutate(diff_sd_CS=(sd_CS-sd_CS[1])/sd_CS[1],
         diff_sd_PS=(sd_PS-sd_PS[1])/sd_PS[1],
         diff_sd_PI=(sd_PI -sd_PI[1])/sd_PI[1],
         diff_CS=(avg_CS-avg_CS[1])/avg_CS[1],
         diff_PS=(avg_PS-avg_PS[1])/avg_PS[1],
         diff_PI=(avg_PI-avg_PI[1])/avg_PI[1])




N_sd0<-ggplot(N_sim0)+geom_line(aes(n,diff_sd_CS*100, color ="CS"), size=1.5, se=FALSE)+
  geom_line(aes(n, diff_sd_PS*100, color="PS"), size=1.25)+
  geom_line(aes(n, diff_sd_PI*100, color="Processor Profit"), size=1.25)+
  ylab("% Change in the Coefficient of Variation")+xlab("")+
  scale_color_manual("", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue"))+
  ylim(-10,10)+
  geom_hline(yintercept=0, lty="dashed")+
  theme_minimal()+
  theme(legend.position = 'top',
        legend.text =element_text(size=18))

N_avg0<-ggplot(N_sim0)+geom_line(aes(n,diff_CS*100, color ="CS"), size=1.25)+
  geom_line(aes(n, diff_PS*100, color="PS"), size=1.25)+
  geom_line(aes(n, diff_PI*100, color="Processor Profit"), size=1.25)+
  ylab("% Change in Surplus")+xlab("")+
  scale_color_manual("", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue", "DWL"="dark red"))+
  ylim(-10,10)+
  geom_hline(yintercept = 0, lty="dashed")+
  theme_minimal()+
  theme(legend.position = 'top',
        legend.text =element_text(size=18))

processors0<-ggarrange(N_sd0,N_avg0,common.legend = TRUE, nrow=1, ncol=2,legend="top")
annotate_figure(processors0, 
                bottom="Number of Processing Firms")
ggsave("Output/FigureA1a.png", scale = 5)



n<-as.vector(seq(6,9, 1))
c=(1-f)/((N[1])^gamma)
N_base<-N/n[1]

N_sim15<-(mapply(simulation,n=n,xi=0.15, theta=0.15, SIMPLIFY = FALSE))%>%
  bind_rows()%>%
  mutate(diff_sd_CS=(sd_CS-sd_CS[1])/sd_CS[1],
         diff_sd_PS=(sd_PS-sd_PS[1])/sd_PS[1],
         diff_sd_PI=(sd_PI -sd_PI[1])/sd_PI[1],
         diff_CS=(avg_CS-avg_CS[1])/avg_CS[1],
         diff_PS=(avg_PS-avg_PS[1])/avg_PS[1],
         diff_PI=(avg_PI-avg_PI[1])/avg_PI[1])





N_sd15<-ggplot(N_sim15)+geom_line(aes(n,diff_sd_CS*100, color ="CS"), size=1.5)+
  geom_line(aes(n, diff_sd_PS*100, color="PS"), size=1.25)+
  geom_line(aes(n, diff_sd_PI*100, color="Processor Profit"), size=1.25)+
  ylab("% Change in the Coefficient of Variation")+xlab("")+
  scale_color_manual("", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue"))+
  ylim(-10,10)+
  geom_hline(yintercept=0, lty="dashed")+
  theme_minimal()+
  theme(legend.position = 'top',
        legend.text =element_text(size=18))

N_avg15<-ggplot(N_sim15)+geom_line(aes(n,diff_CS*100, color ="CS"), size=1.5)+
  geom_line(aes(n, diff_PS*100, color="PS"), size=1.25)+
  geom_line(aes(n, diff_PI*100, color="Processor Profit"), size=1.25)+
  ylab("% Change in Surplus")+xlab("")+
  geom_hline(yintercept=0, lty="dashed")+
  theme_minimal()+
  scale_color_manual("", values=c("PS"="orange", "CS"="dark green", "Processor Profit"="dark blue", "DWL"="dark red"))+
  ylim(-10,10)+
  theme(legend.position = 'top',
        legend.text =element_text(size=18))

processors15<-ggarrange(N_sd15,N_avg15,common.legend = TRUE, nrow=1, ncol=2,legend="top")
annotate_figure(processors15, 
                bottom="Number of Processing Firms")
ggsave("Output/FigureA1b.png", scale = 5)



n<-as.vector(seq(3,5, 1))
c=(1-f)/((N[1])^gamma)
N_base<-N/n[1]

N_sim30<-(mapply(simulation, n=n,xi=0.3, theta=0.3, SIMPLIFY = FALSE))%>%
  bind_rows()%>%
  mutate(diff_sd_CS=(sd_CS-sd_CS[1])/sd_CS[1],
         diff_sd_PS=(sd_PS-sd_PS[1])/sd_PS[1],
         diff_sd_PI=(sd_PI -sd_PI[1])/sd_PI[1],
         diff_CS=(avg_CS-avg_CS[1])/avg_CS[1],
         diff_PS=(avg_PS-avg_PS[1])/avg_PS[1],
         diff_PI=(avg_PI-avg_PI[1])/avg_PI[1])

N_sd30<-ggplot(N_sim30)+geom_line(aes(n,diff_sd_CS*100, color ="CS"), size=1.5)+
  geom_line(aes(n, diff_sd_PS*100, color="PS"), size=1.25)+
  geom_line(aes(n, diff_sd_PI*100, color="Processor Profit"), size=1.25)+
  ylab("% Change in the Coefficient of Variation")+xlab("")+
  theme_minimal()+
  scale_x_continuous(breaks=c(3,4,5))+
  geom_hline(yintercept=0, lty="dashed")+
  scale_color_manual("", values=c("PS"="orange", "CS"="dark green", "Processor Profit"="dark blue"))+
  ylim(-10,10)+
  theme_minimal()+
  theme(legend.position = 'top',
        legend.text =element_text(size=18))


N_avg30<-ggplot(N_sim30)+geom_line(aes(n,diff_CS*100, color ="CS"), size=1.5)+
  geom_line(aes(n, diff_PS*100, color="PS"), size=1.25)+
  geom_line(aes(n, diff_PI*100, color="Processor Profit"), size=1.25)+
  geom_hline(yintercept=0, lty="dashed")+
  scale_x_continuous(breaks=c(3,4,5))+
  ylab("% Change in Surplus")+xlab("")+
  theme(legend.position = 'top')+
  scale_color_manual("", values=c("PS"="orange", "CS"="dark green","Processor Profit"="dark blue", "DWL"="dark red"))+
  ylim(-10,10)+
  theme_minimal()+
  theme(legend.position = 'top',
        legend.text =element_text(size=18))




processors30<-ggarrange(N_sd30,N_avg30,common.legend = TRUE, nrow=1, ncol=2,legend="top")
annotate_figure(processors30, 
                bottom="Number of Processing Firms")
ggsave("Output/FigureA1c.png", scale = 5)
