simulation<-function(n=1,psi=1, xi=0.1,omega=0, eta = 0.7, epsilon=1, theta=0.1, N=40){
set.seed(12345)
distTypes<-c("halfnorm","halfnorm", "binom")

#Specify the correlation between variables. 
#Elements correspond to the correlations: c([1,2], [1,3], [1,4], [1,5], [2,3], etc.)
myCop <- normalCopula(param=c(psi*0.25, -psi*0.5, psi*0.1),
                      dim = 3, dispstr = "un")

#Provides the inputs for multivariate distributions. We supply our distributions to the margins function
#parmsMargins lists inputs for distribution specific parameters. i.e. theta belongs to half norm
myMvd <- mvdc(copula=myCop,
              margins=distTypes,
              paramMargins=list(list(theta=2),
                                list(theta=10),
                                list(N, prob=0.75)))
                                
draws<-data.frame(rMvdc(100000, myMvd))
colnames(draws)<-c("demand", "supply", "processor")
Nt<-draws$processor


#####Inputs######

alpha = 1/eta
f=0.15
beta = f*n/epsilon
a=1+alpha
b=f-beta/n

g=0.95


c=(1-f)/(N^0.3)
cw=c*N^0.3

Qoo_fix<-(a*(1-xi/eta)-b*(1+theta/epsilon)-cw)/(alpha*(1-xi/eta)+(beta/n)*(1+theta/epsilon))


#Incorporate Shocks
a=a+draws$demand
b=b+draws$supply


#Competitive Equilibrium
Qc<-(a-b-cw)/(alpha+beta/n)
Qci<-(a-b-cw)/(n*alpha+beta)


#Oligopoly,Oligopsony Equilibrium
#Update Beta
beta<-beta*N/Nt
#New Quantity with shutdowns
Qoo<-(a*(1-xi/eta)-b*(1+theta/epsilon)-cw)/(alpha*(1-xi/eta)+(beta)*(1+theta/epsilon))

Pwoo<-a-alpha*Qoo
Pfoo<-b+beta*Qoo


#Welfare
CS<-(a-Pwoo)*Qoo/2
PS<-(Pfoo-b)*Qoo/2
PI<-(Pwoo-Pfoo-cw)*Qoo

return(data.frame(avg_Qoo=mean(Qoo), 
                  sd_Qoo=sd(Qoo)/mean(Qoo),
                  avg_Pfoo=mean(Pfoo),
                  sd_pfoo=sd(Pfoo)/mean(Pfoo),
                  avg_Pwoo=mean(Pwoo),
                  sd_Pwoo=sd(Pwoo)/mean(Pwoo),
                  avg_CS=mean(CS),
                  sd_CS=sd(CS)/mean(CS),
                  avg_PS=mean(PS),
                  sd_PS=sd(PS)/mean(PS),
                  avg_PI=mean(PI),
                  sd_PI=sd(PI)/mean(PI)
                  
                  ))

}

####Figure 2 #####

N=40
distTypes<-c("halfnorm","halfnorm", "binom")
set.seed(12345)

#Specify the correlation between variables. 
#Elements correspond to the correlations: c([1,2], [1,3], [1,4], [1,5], [2,3], etc.)
myCop <- normalCopula(param=c(0.25, .5, 0.1),
                      dim = 3, dispstr = "un")

#Provides the inputs for multivariate distributions. We supply our distributions to the margins function
#parmsMargins lists inputs for distribution specific parameters. i.e. theta belongs to half norm
myMvd <- mvdc(copula=myCop,
              margins=distTypes,
              paramMargins=list(list(theta=2),
                                list(theta=10),
                                list(N, prob=0.75)))

draws<-data.frame(rMvdc(100000, myMvd))
colnames(draws)<-c("demand", "supply", "processor")
Nt<-draws$processor


shocks1<-ggplot(draws)+geom_density(aes(demand, fill="Demand"), alpha=0.5)+geom_density(aes(supply, fill="Supply"), alpha=0.5)+scale_fill_manual("Shocks",values=c("Demand"="orange", "Supply"="dark green"))+ylab("Density")+xlab("")
shocks2<-ggplot(draws)+geom_density(aes((1-(processor)/N)*100, fill="Processor Shutdown"), alpha=0.5)+scale_fill_manual("Shutdown", values = c("Processor Shutdown"="dark blue"))+ylab("Density")+xlab("% of Processors")+xlim(0,50)


ggarrange(shocks1, shocks2)
ggsave("Output/Figure2.png", scale=5)

#####Figure 3 ################

psi<-seq(0,0.5,0.02)

cor_sim<-(mapply(simulation,psi=psi,xi=0.15,theta=0.15, n=1,N=40, SIMPLIFY = FALSE))%>%
  bind_rows()%>%
  mutate(diff_sd_CS=(sd_CS-sd_CS[1])/sd_CS[1],
         diff_sd_PS=(sd_PS-sd_PS[1])/sd_PS[1],
         diff_sd_PI=(sd_PI -sd_PI[1])/sd_PI[1],
         diff_CS=(avg_CS-avg_CS[1])/avg_CS[1],
         diff_PS=(avg_PS-avg_PS[1])/avg_PS[1],
         diff_PI=(avg_PI-avg_PI[1])/avg_PI[1])



cor_sd<-ggplot(cor_sim)+geom_smooth(aes(psi, diff_sd_PS*100, color="PS & CS"), size=1.5, se=F)+
  geom_smooth(aes(psi, diff_sd_PI*100, color="Processor Profit"), se=F)+
  ylab("% Change in CV")+
  ylim(-10,10)+
  xlab(expression(rho))+
  theme_minimal()+
  scale_color_manual("Welfare", values=c("PS & CS"="orange", "Processor Profit"="dark blue"))
cor_sd
ggsave("Output/Figure3.png", scale=5)


