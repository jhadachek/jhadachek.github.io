RetailSales<- read_excel("RawData/NationalTotalAndSubcategory.xlsx", sheet=2)

colnames(RetailSales)<-c(RetailSales[1,])

meat<-RetailSales%>%
  filter(Category=="Meats, eggs, and nuts", Subcategory=="Regular meat fresh/frozen")%>%
  mutate(Date=as.Date(Date, format = "%Y-%m-%d"))%>%
  dplyr::select(Date, Dollars, `Unit sales`, `Volume sales`)%>%
  mutate(week=week(Date), year=year(Date))

USweeklyslaughter <- read_excel("RawData/USweeklyslaughter.xls", 
                                sheet = "Sheet3", col_types = c("date", "text"))%>%
  rename(Date=...1)%>%
  mutate(week=week(Date), year=year(Date))%>%
  group_by(week, year)%>%
  mutate(Actual=as.numeric(Actual))%>%
  summarize(slaughter=sum(Actual))

final<-meat%>%
  dplyr::select(!Date)%>%
  left_join(USweeklyslaughter)%>%
  mutate(Dollars=as.numeric(Dollars), `Volume sales`=as.numeric(`Volume sales`))%>%  filter(!is.na(slaughter))

final$diff_slaughter<-log(final$slaughter)-mean(log(final$slaughter))
final$diff_sales<-log(final$Dollars)-mean(log(final$Dollars))


fig1<-final%>%
  filter(year==2020 & week<41)%>%
    mutate(beginning = ymd(str_c("2020-01-01")),
           final_date = beginning + weeks(week))%>%
ggplot()+annotate("rect",xmin=ymd(str_c("2020-03-15")), xmax=ymd(str_c("2020-07-01")), ymin=-Inf, ymax=Inf, fill="lightgrey", alpha=0.5)+
  geom_point(aes(final_date, diff_slaughter*100, color="Slaughter"), size=2)+
  geom_point(aes(final_date, diff_sales*100, color="Retail"), size=2)+
    ylab("% Deviation from Average")+
    xlab("2020")+
   geom_vline(xintercept = ymd(str_c("2020-03-15")))+
  geom_vline(xintercept = ymd(str_c("2020-07-01")))+
    theme_minimal()+
  scale_color_manual("Market for Beef", values=c("Slaughter"="dark blue", "Retail"="orange"))

fig1
ggsave("Output/Figure1.png", scale=5)
