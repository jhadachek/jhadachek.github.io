g=0.95
gamma=1-g
f=0.3
N=40

#Fix cost, so that cw=1-f
c=(1-f)/((N)^gamma)

#Solves for the vector of cw, where each element corresponds to cw for n=1,=2
n=c(1,2)
cw_fix=c*(n*N)^(gamma)

simulation<-function(n=1,psi=1, xi=0.1,omega=0, eta = 0.7, epsilon=1, theta=0.1, N=40){
set.seed(12345)

#Single region case
if (n==1){
distTypes<-c("halfnorm","halfnorm", "binom")

#Specify the correlation between variables. 
#Elements correspond to the correlations: c([1,2], [1,3], [1,4], [1,5], [2,3], etc.)
#Three (for 1 region) shock parameters.
myCop <- normalCopula(param=c(psi*0.25,psi*-0.5, psi*0.1),
                      dim = 3, dispstr = "un")

#Provides the inputs for multivariate distributions. We supply our distributions to the margins function
#parmsMargins lists inputs for distribution specific parameters. i.e. theta belongs to half norm
myMvd <- mvdc(copula=myCop,
              margins=distTypes,
              paramMargins=list(list(theta=2),#First, the halfnormal demand shock
                                list(theta=10),#These are the production shock distrubutions
                                list(N, prob=0.75)))#Then the shutdowns shock.
                                
draws<-data.frame(rMvdc(100000, myMvd))
colnames(draws)<-c("demand", "supply", "processor")
Nt<-draws$processor
draws$demand<-draws$demand

#Two regions case
  }else if(n==2){
    distTypes<-c("halfnorm","halfnorm","halfnorm", "binom", "binom")
    
        myCop <- normalCopula(param=c(psi*0.25,psi*0.25,
                                  psi*-0.5, psi*-0.5,
                                  0, psi*0.1,0,0,psi*0.1,0),
                          dim = 5, dispstr = "un")
    
        myMvd <- mvdc(copula=myCop,
                  margins=distTypes,
                  paramMargins=list(list(theta=2),#First, the halfnormal demand shock
                                    list(theta=10),#These are the production shock distrubutions
                                    list(theta=10),
                                    list(N, prob=0.75),#Shutdowns
                                    list(N, prob=0.75)))
    
    draws<-data.frame(rMvdc(100000, myMvd))
    colnames(draws)<-c("demand", "supply1","supply2", "processor1", "processor2")
    draws$demand<-draws$demand
    draws$supply1<-draws$supply1
    draws$supply2<-draws$supply2
    Nt1<-draws$processor1
    Nt2<-draws$processor2
  }
  
  

#####Inputs######

eta=0.7
epsilon=1
alpha = 1/eta
f=0.30
beta = f/epsilon
a=1+alpha
b=f-beta


g=0.95

# If a single supply region.
if (n==1){

#Incorporate Shocks
a=a+draws$demand
b=b+draws$supply
cw=cw_fix[1]

#Competitive Equilibrium
Qc<-(a-b-cw)/(alpha+beta/n)
Qci<-(a-b-cw)/(n*alpha+beta)

#Update Beta
beta<-beta*N/Nt

#Oligopoly,Oligopsony Equilibrium
Qoo_flex1<-(a*(1-xi/eta)-b*(1+theta/epsilon)-cw)/(alpha*(1-xi/eta)+(beta)*(1+theta/epsilon))
#No supply from region 2
Qoo_flex2<-0

#Processor level q
#qoo<-Qoo_flex1/N
#New Quantity with shutdowns
Qoo<-Qoo_flex1
Qoo2<-Qoo_flex1+Qoo_flex2

Pwoo<-a-alpha*Qoo
Pfoo1<-b+beta*Qoo
Pfoo2<-0
Pfoo<-Pfoo1


#Welfare
CS<-(a-Pwoo)*Qoo/2
PS1<-(Pfoo-b)*Qoo/2
PS2<-0
PS<-PS1+PS2
PI1<-(Pwoo-Pfoo-cw)*Qoo
PI2<-0
PI<-PI1+PI2
DWL<-(Pwoo-Pfoo)*(Qc-Qoo)/2-cw*(Qc-Qoo)


#If we expand supply to region 2
}else if(n==2){

   #Incorporate Shocks
    #Farm production penalty
    k=0.069
    a=a+draws$demand
    #Supply region 1 shock
    b1=b+draws$supply1
    #Supply region 2 shock
    b2=b+draws$supply2+k
    #Pulls second element of the cost vector
    cw=cw_fix[2]
    
    b_bar=(b1+b2)/2
    
    #Competitive Equilibrium
    Qc<-(a-(b1+b2)/2-cw)/(alpha+beta/n)
    Qci<-(a-(b1+b2)/2-cw)/(n*alpha+beta)
    
    #Oligopoly,Oligopsony Equilibrium
   beta1<-beta*N/Nt1
    beta2<-beta*N/Nt2
    B<-b1*beta2+b2*beta1
    
    Qoo<-(a*(beta1+beta2)*(1-xi/eta)- B*(1+theta/epsilon) - (beta1+beta2)*cw)/(alpha*(beta1+beta2)*(1-xi/eta)+2*beta1*beta2*(1+theta/epsilon))

    Qoo_flex1<-((a-alpha*Qoo)*(1-xi/eta) - cw)/(2*beta1*(1+theta/epsilon)) - b1/(2*beta1)
    Qoo_flex2<-((a-alpha*Qoo)*(1-xi/eta) - cw)/(2*beta2*(1+theta/epsilon)) - b2/(2*beta2)
    
    
    #Total final throughput
    Qoo2=Qoo_flex1+Qoo_flex2
    
    #National demand
    Pwoo<-a-alpha*Qoo
    #Region 1 supply function
    Pfoo1<-b1+2*beta1*Qoo_flex1
    #Region 2 supply function
    Pfoo2<-b2+2*beta2*Qoo_flex2
    
    #Avg farm price
    Pfoo=(Pfoo1+Pfoo2)/2

    
    #Welfare
    CS<-(a-Pwoo)*Qoo/2
    PS1<-(Pfoo1-b1)*Qoo_flex1/2
    PS2<-(Pfoo2-b2)*Qoo_flex2/2
    PS<-(PS1+PS2)
    PI1<-(Pwoo-Pfoo1-cw)*Qoo_flex1
    PI2<-(Pwoo-Pfoo2-cw)*Qoo_flex2
    PI<-PI1+PI2
}




return(data.frame(avg_Qoo=mean(Qoo),
                  Qoo2=mean(Qoo2),
                  avg_Qoo1=mean(Qoo_flex1),
                  avg_Qoo2=mean(Qoo_flex2),
                  sd_Qoo=sd(Qoo)/mean(Qoo),
                  avg_Pfoo=mean(Pfoo),
                  avg_Pfoo1=mean(Pfoo1),
                  avg_Pfoo2=mean(Pfoo2),
                  sd_pfoo=sd(Pfoo)/mean(Pfoo),
                  avg_Pwoo=mean(Pwoo),
                  sd_Pwoo=sd(Pwoo)/mean(Pwoo),
                  avg_CS=mean(CS),
                  sd_CS=sd(CS)/mean(CS),
                  avg_PS1=mean(PS1),
                  avg_PS2=mean(PS2),
                  avg_PS=mean(PS),
                  sd_PS=sd(PS),
                  sd_PS1=sd(PS1)/mean(PS1),
                  sd_PS2=sd(PS2)/mean(PS2),
                  avg_PI1=mean(PI1),
                  avg_PI2=mean(PI2),
                  avg_PI=mean(PI),
                  sd_PI1=sd(PI1)/mean(PI1), 
                  sd_PI2=sd(PI2)/mean(PI2),
                  sd_PI=sd(PI)
                  ))

}


############################Increasing Number of Regions####################
#Increasing from 1 to 2 regions
n<-seq(1,2,1)

region_sim0<-(mapply(simulation,psi=1,xi=0,theta=0, n=n,N=40, SIMPLIFY = FALSE))%>%
  bind_rows()%>%
    mutate(diff_sd_CS=(sd_CS-sd_CS[1])/sd_CS[1],
           diff_sd_PS=(sd_PS-sd_PS[1])/sd_PS[1],
           diff_sd_PI=(sd_PI -sd_PI[1])/sd_PI[1],
           diff_CS=(avg_CS-avg_CS[1])/avg_CS[1],
           diff_PS=(avg_PS-avg_PS[1])/avg_PS[1],
           diff_PI=(avg_PI-avg_PI[1])/avg_PI[1])


region_sd0<-ggplot(region_sim0)+geom_line(aes(n, diff_sd_CS*100, color="CS"), size=1.5 )+
    geom_line(aes(n, diff_sd_PS*100, color="PS"), size=1.25)+
    geom_line(aes(n, diff_sd_PI*100, color="Processor Profit"), size=1.25)+
    ylab("% Change in the Coefficient of Variation")+
    xlab("")+
    scale_x_discrete("", limits=c("1","2"), expand = expansion(0.1))+
    #geom_label(aes(x=2.5, y=0.55),label=expression(xi~ "=" ~ theta ~"=0"),size=8)+
    ylim(c(-20,20))+
    geom_hline(yintercept = 0, lty="dashed")+
    scale_color_manual("Surplus", values=c("PS"="orange","CS"="darkgreen","Processor Profit"="dark blue"))+
    theme_minimal()+
    theme(legend.position = "top",
          legend.text = element_text(size=18))

region_avg0<-ggplot(region_sim0)+geom_line(aes(n, diff_PI*100, color="Processor Profit"), size=1.25)+
    geom_line(aes(n, diff_CS*100, color="CS"), size=1.5)+
    geom_line(aes(n, diff_PS*100, color="PS"), size=1.25, alpha=0.95)+
    ylab("% Change in Suprlus")+
    xlab("")+
    scale_x_discrete("", limits=c("1","2"), expand = expansion(0.1))+
    ylim(c(-20,20))+
    theme_minimal()+
    geom_hline(yintercept=0, lty="dashed")+
    scale_color_manual("Surplus", values=c("PS"="orange","CS"="Dark Green", "Processor Profit"="dark blue"))+
    theme_minimal()+
    theme(legend.position = "top",
          legend.text = element_text(size=18))

region_sim15<-(mapply(simulation,psi=1,xi=0.15,theta=0.15, n=n,N=40, SIMPLIFY = FALSE))%>%
  bind_rows()%>%
    mutate(diff_sd_CS=(sd_CS-sd_CS[1])/sd_CS[1],
           diff_sd_PS=(sd_PS-sd_PS[1])/sd_PS[1],
           diff_sd_PI=(sd_PI -sd_PI[1])/sd_PI[1],
           diff_CS=(avg_CS-avg_CS[1])/avg_CS[1],
           diff_PS=(avg_PS-avg_PS[1])/avg_PS[1],
           diff_PI=(avg_PI-avg_PI[1])/avg_PI[1])



region_sd15<-ggplot(region_sim15)+geom_line(aes(n, diff_sd_CS*100, color="CS"), size=1.5 )+
  geom_line(aes(n, diff_sd_PS*100, color="PS"), size=1.25)+
  geom_line(aes(n, diff_sd_PI*100, color="Processor Profit"), size=1.25)+
  ylab("% Change in CV")+
  xlab("")+
  scale_x_discrete("", limits=c("1","2"), expand = expansion(0.1))+
  ylim(c(-20,20))+
  theme_minimal()+
  geom_hline(yintercept = 0, lty="dashed")+
  scale_color_manual("Surplus", values=c("PS"="orange","CS"="dark green","Processor Profit"="dark blue"))+
    theme_minimal()+
    theme(legend.position = "top",
          legend.text = element_text(size=18))

region_avg15<-ggplot(region_sim15)+geom_line(aes(n, diff_CS*100, color="CS"), size=1.5)+
  geom_line(aes(n, diff_PS*100, color="PS"), size=1.25)+
  geom_line(aes(n, diff_PI*100, color="Processor Profit"), size=1.25)+
  ylab("% Change in Suprlus")+
  xlab("")+
  scale_x_discrete("", limits=c("1","2"), expand = expansion(0.1))+
  ylim(c(-20,20))+
  theme_minimal()+
  geom_hline(yintercept=0, lty="dashed")+
  scale_color_manual("Surplus", values=c("PS"="orange", "CS"="dark green", "Processor Profit"="dark blue"))+
    theme_minimal()+
    theme(legend.position = "top",
          legend.text = element_text(size=18))


region_sim30<-(mapply(simulation,psi=1,xi=0.3,theta=0.3, n=n,N=40, SIMPLIFY = FALSE))%>%
    bind_rows()%>%
  mutate(diff_sd_CS=(sd_CS-sd_CS[1])/sd_CS[1],
         diff_sd_PS=(sd_PS-sd_PS[1])/sd_PS[1],
         diff_sd_PI=(sd_PI -sd_PI[1])/sd_PI[1],
         diff_CS=(avg_CS-avg_CS[1])/avg_CS[1],
         diff_PS=(avg_PS-avg_PS[1])/avg_PS[1],
         diff_PI=(avg_PI-avg_PI[1])/avg_PI[1])


region_sd30<-ggplot(region_sim30)+ geom_line(aes(n, diff_sd_PI*100, color="Processor Profit"), size=1.25)+
    geom_line(aes(n, diff_sd_CS*100, color="CS"), size=1.5 )+
  geom_line(aes(n, diff_sd_PS*100, color="PS"), size=1.25)+
  ylab("% Change in CV")+
  xlab("")+
  scale_x_discrete("", limits=c("1","2"), expand = expansion(0.1))+
  ylim(c(-20,20))+
  theme_minimal()+
  geom_hline(yintercept = 0, lty="dashed")+
  scale_color_manual("Surplus", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue"))+
    theme_minimal()+
    theme(legend.position = "top",
          legend.text = element_text(size=18))

region_avg30<-ggplot(region_sim30)+ geom_line(aes(n, diff_PI*100, color="Processor Profit"), size=1.5)+
    geom_line(aes(n, diff_CS*100, color="CS"), size=1.5)+
  geom_line(aes(n, diff_PS*100, color="PS"), size=1.25, alpha=0.95)+
  ylab("% Change in Suprlus")+
  xlab("")+
  scale_x_discrete("", limits=c("1","2"), expand = expansion(0.1))+
  ylim(c(-20,20))+
  theme_minimal()+
  geom_hline(yintercept=0, lty="dashed")+
  scale_color_manual("Surplus", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue"))+
    theme_minimal()+
    theme(legend.position = "top",
          legend.text = element_text(size=18))

compete<-ggarrange(region_sd0, region_avg0, common.legend = TRUE, legend="top", nrow=1)
annotate_figure(compete, 
                bottom="Number of Production Regions")


moderate<-ggarrange(region_sd15, region_avg15, common.legend = TRUE, legend="top", nrow=1)
annotate_figure(moderate, 
                bottom="Number of Production Regions")


high<-ggarrange(region_sd30, region_avg30, common.legend = TRUE,legend="top", nrow=1)
annotate_figure(high, 
                bottom="Number of Production Regions")

df<-data.frame(mp=c("Competitive","Competitive","Competitive",
                    "Moderate","Moderate","Moderate",
                    "High","High","High"), agent=c("CS","PS","Processor Profit",
                                             "CS","PS","Processor Profit",
                                             "CS","PS","Processor Profit"),
               change=c(region_sim0$diff_CS[2], region_sim0$diff_PS[2], 0,
                        region_sim15$diff_CS[2], region_sim15$diff_PS[2], region_sim15$diff_PI[2],
                        region_sim30$diff_CS[2], region_sim30$diff_PS[2], region_sim30$diff_PI[2]))

df_sd<-data.frame(mp=c("Competitive","Competitive","Competitive",
                    "Moderate","Moderate","Moderate",
                    "High","High","High"), agent=c("CS","PS","Processor Profit",
                                                   "CS","PS","Processor Profit",
                                                   "CS","PS","Processor Profit"),
               change=c(region_sim0$diff_sd_CS[2], region_sim0$diff_sd_PS[2], 0,
                        region_sim15$diff_sd_CS[2], region_sim15$diff_sd_PS[2], region_sim15$diff_sd_PI[2],
                        region_sim30$diff_sd_CS[2], region_sim30$diff_sd_PS[2], region_sim30$diff_sd_PI[2]))


df$mp<-factor(df$mp, levels=c("Competitive", "Moderate","High"), ordered=TRUE)
df_sd$mp<-factor(df_sd$mp, levels=c("Competitive", "Moderate","High"), ordered=TRUE)


bar_surplus<-ggplot(df)+geom_bar(aes(x=mp, y=(change*100), fill=agent), width=0.7, stat="identity", position="dodge")+
  scale_fill_manual("Surplus", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue"))+
  ylab("% Change in Suprlus")+
  xlab("")+
  ylim(c(-20,20))+
  theme_minimal()+
  geom_hline(yintercept = 0, lty="dashed")+
  theme(legend.position = "top",
        legend.text = element_text(size=18))
  
bar_sd<-ggplot(df_sd)+geom_bar(aes(x=mp, y=(change*100), fill=agent), width=0.7, stat="identity", position="dodge")+
  scale_fill_manual("Surplus", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue"))+
  ylab("% Change in the Coefficient of Variation")+
  xlab("")+
  ylim(c(-20,20))+
  theme_minimal()+
  geom_hline(yintercept = 0, lty="dashed")+
  theme(legend.position = "top",
        legend.text = element_text(size=18))

bar<-ggarrange(bar_sd, bar_surplus, common.legend = TRUE, legend="top", nrow=1)
annotate_figure(bar, 
                bottom="Market Power")
ggsave("Output/Figure9.png", scale=5)
