#Simulation function given market structure inputs
simulation<-function(n=1, psi=1, theta=0.1, xi=0.1, omega=0, N=40){
set.seed(12345)
#Naming the types of distributions
##Here: sigma (demand)~halfnorm, mu (production)~ halfnorm, rho (shutdowns)~binom
    
distTypes<-c("halfnorm","halfnorm","binom")

#Specify the correlation between variables. 
#Elements correspond to the correlations: c([1,2], [1,3], [1,4], [1,5], [2,3], etc.)
#3 shock parameters now, but can be expanded if needed. 
myCop <- normalCopula(param=c(psi*0.25, psi*-0.5, psi*0.1),
                      dim = 3, dispstr = "un")

#Provides the inputs for multivariate distributions. We supply our distributions to the margins function
#parmsMargins lists inputs for distribution specific parameters. i.e. theta belongs to half norm
myMvd <- mvdc(copula=myCop,
              margins=distTypes,
              paramMargins=list(list(theta=2),#First, the halfnormal demand shock
                                list(theta=10),#This is the production shock distribution.
                                list(N, prob=0.75)))#This is the production shock distribution

#Pulls 100,000 draws/shocks                                
draws<-data.frame(rMvdc(100000, myMvd))
colnames(draws)<-c("demand", "supply", "processor")
draws$demand<-draws$demand
# shutdown shocks
Nt<-draws$processor

#######################
##Parameters
#######################

eta=0.7
epsilon=1
alpha = 1/eta
f=0.30
beta = f*n/epsilon
a=1+alpha
b=f-beta/n

#Fixed cost function
c=(1-f)/(N^0.3)
cw=c*N^0.3

#######################
## Calculate Equilibria
#######################


#Step 1: Compute pre-shock equilibrium 
Qoo_fix<-(a*(1-xi/eta)-b*(1+theta/epsilon)-cw)/(alpha*(1-xi/eta)+(beta/n)*(1+theta/epsilon))
#Pre-shock fixed prices
Pwoo_fix<-a-alpha*Qoo_fix

#Farm Supply with fixed prices
Pfoo_fix<-b+beta*Qoo_fix


#Step 2: Assign parallel shocks
a=a+draws$demand
b=b+draws$supply


###Competitive Equilibrium
##Qc is normalized to 1

Qc<-(a-b-cw)/(alpha+beta/n)
Qci<-(a-b-cw)/(n*alpha+beta)

#Step 3: Compute Oligopoly-Oligopsony Equilibrium Post-Shock, Flexible Prices
Qoo_flex<-(a*(1-xi/eta)-b*(1+theta/epsilon)-cw)/(alpha*(1-xi/eta)+(beta*N/Nt)*(1+theta/epsilon))

#Flexible Equilibrium Price
Pwoo_flex<-a-alpha*Qoo_flex

#Step 4: Updating: Omega determines the extent to which prices are "sticky" [0,0.5]
Pwoo<-pmin(Pwoo_flex, Pwoo_fix*(1+omega/100))

#Quantity demanded with updated market price

#Quantity where demand curve meets the price
Qd<-(a-Pwoo)/alpha
#Quantity where PMC meets the price
Q_pmc<- (Pwoo-cw)/(1+theta/epsilon)/(beta*N/Nt) - b/(beta*N/Nt)

#Determine the binding quantity: Case 1 or Case 2
Qoo<-pmax(pmin(Qd, Q_pmc),0)

#Step 5: New Quantity with shutdowns
Pwoo2<-a-alpha*Qoo 

#Step 6: Final equilibria outcomes
Pfoo<-b+beta*N/Nt*Qoo
shortage=pmax(Qd-Qoo, 0)

#CS with random allocation of excess demand
CS<-(a-Pwoo)*Qoo/2*Qoo/Qd
PS<-(Pfoo-b)*Qoo/2
PI<-(Pwoo-Pfoo-cw)*Qoo
wages<-cw*Qoo
DWL<-(Pwoo-Pfoo-cw)*(Qc-Qoo)/2+cw*(Qc-Qoo)+ (a-Pwoo)*Qoo/2*(Qd-Qoo)/Qd

#######################
# Mean and CV
#######################

return(data.frame(avg_Qoo=mean(Qoo), 
                  avg_Qd=mean(Qd), 
                  avg_PMC=mean(Q_pmc),
                  avg_Pwoo2=mean(Pwoo2),
                  Qoo_flex=mean(Qoo_flex),
                  xi=xi,
                  sd_Qoo=sd(Qoo)/mean(Qoo),
                  sd_Qoo=sd(Qoo),
                  wages=mean(wages),
                  avg_Pfoo=mean(Pfoo),
                  avg_Pwoo=mean(Pwoo),
                  avg_CS=mean(CS),
                  sd_CS=sd(CS)/mean(CS),
                  avg_PS=mean(PS),
                  sd_PS=sd(PS)/mean(PS),
                  avg_PI=mean(PI),
                  sd_PI=sd(PI)/mean(PI), 
                  avg_DWL=mean(DWL),
                  sd_DWL=sd(DWL)/mean(DWL),
                  shortage = mean(shortage),
                  Qd=mean(Qd)
                  ))

}

#######################
# vary omega
#######################

omega<-seq(60,0, -2)

#######################
# Plots
#######################

price0<-(mapply(simulation,psi=1,xi=0,theta=0,omega=omega, n=1,N=100, SIMPLIFY = FALSE))%>%
  bind_rows()%>%
  mutate(surplus=avg_CS+avg_PS+avg_PI+avg_DWL+wages, 
         share_CS=avg_CS/surplus, 
         share_PS=avg_PS/surplus, 
         share_PI=avg_PI/surplus, 
         share_dwl=avg_DWL/surplus)%>%
    mutate(diff_sd_CS=(sd_CS-sd_CS[1])/sd_CS[1],
           diff_sd_PS=(sd_PS-sd_PS[1])/sd_PS[1],
           diff_sd_PI=(sd_PI -sd_PI[1])/sd_PI[1],
           diff_CS=(avg_CS-avg_CS[1])/avg_CS[1],
           diff_PS=(avg_PS-avg_PS[1])/avg_PS[1],
           diff_PI=(avg_PI-avg_PI[1])/avg_PI[1],
           diff_shortage=(shortage-shortage[1])/shortage[1])


price_avg0<-ggplot(price0)+
  geom_smooth(aes(omega, diff_PS*100, color="PS"),se=F, size=1.25)+
  geom_smooth(aes(omega, diff_CS*100, color="CS"),se=F, size=1.25)+
  ylab("% Change in Surplus")+
  xlab("")+
  ylim(c(-100,100))+
  scale_x_reverse()+
  theme_minimal()+
  geom_hline(yintercept=0, lty="dashed")+
  scale_color_manual("", values=c("PS"="orange", "CS"="dark green", "Processor Profit"="dark blue"))+
    theme_minimal()+
    theme(legend.position = 'top',
          legend.text =element_text(size=18))
                     
#Low Market Power

price_sd0<-ggplot(price0)+geom_smooth(aes(omega, diff_sd_CS*100, color="CS"),se=F, size=1.25)+
  geom_smooth(aes(omega, diff_sd_PS*100, color="PS"),se=F, size=1.25)+
  ylab("% Change in the Coefficient of Variation")+
  xlab("")+
  scale_x_reverse()+
  ylim(c(-100,100))+
  geom_hline(yintercept=0, lty="dashed")+
  scale_color_manual("", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue"))+
    theme_minimal()+
    theme(legend.position = 'top',
          legend.text =element_text(size=18))

shortage0<-ggplot(price0)+theme_minimal()+geom_smooth(aes(omega, shortage, color="dark red"))+ylab("Shortage")+xlab("")+ylim(c(0,1))



#Moderate Market Power

price15<-(mapply(simulation,psi=1,xi=0.15,theta=0.15,omega=omega, n=1,N=100, SIMPLIFY = FALSE))%>%
    bind_rows()%>%
    mutate(surplus=avg_CS+avg_PS+avg_PI+avg_DWL+wages, 
           share_CS=avg_CS/surplus,
           share_PS=avg_PS/surplus,
           share_PI=avg_PI/surplus,
           share_dwl=avg_DWL/surplus)%>%
    mutate(diff_sd_CS=(sd_CS-sd_CS[1])/sd_CS[1],
           diff_sd_PS=(sd_PS-sd_PS[1])/sd_PS[1],
           diff_sd_PI=(sd_PI -sd_PI[1])/sd_PI[1],
           diff_CS=(avg_CS-avg_CS[1])/avg_CS[1],
           diff_PS=(avg_PS-avg_PS[1])/avg_PS[1],
           diff_PI=(avg_PI-avg_PI[1])/avg_PI[1],
           diff_shortage=(shortage-shortage[1])/shortage[1])



price_avg15<-ggplot(price15)+
  geom_smooth(aes(omega, diff_PS*100, color="PS"), size=1.25)+
  geom_smooth(aes(omega, diff_CS*100, color="CS"), size=1.25)+
  geom_smooth(aes(omega, diff_PI*100, color="Processor Profit"), size=1.25)+
  ylab("% Change in Surplus")+
  xlab("")+
  ylim(c(-100,100))+
  scale_x_reverse()+
  geom_hline(yintercept=0, lty="dashed")+
  scale_color_manual("", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue"))+
    theme_minimal()+
    theme(legend.position = 'top',
          legend.text =element_text(size=18))


price_sd15<-ggplot(price15)+
  geom_smooth(aes(omega, diff_sd_CS*100, color="CS"), size=1.25, se=F)+
  geom_smooth(aes(omega, diff_sd_PS*100, color="PS"), size=1.25, se=F)+
  geom_smooth(aes(omega, diff_sd_PI*100, color="Processor Profit"), size=1.25, se=F)+
  ylab("% Change in the Coefficient of Variation")+
  xlab("")+
  ylim(c(-100,100))+
  scale_x_reverse()+
  geom_hline(yintercept = 0, lty="dashed")+
  scale_color_manual("", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue"))+
    theme_minimal()+
    theme(legend.position = 'top',
          legend.text =element_text(size=18))

shortage15<-ggplot(price15)+theme_minimal()+geom_smooth(aes(omega, shortage, color="dark red"))+ylab("Shortage")+xlab("")+ylim(c(0,1))


#High Market Power

price30<-(mapply(simulation,psi=1,xi=0.3,theta=0.3,omega=omega, n=1,N=100, SIMPLIFY = FALSE))%>%
    bind_rows()%>%
    mutate(surplus=avg_CS+avg_PS+avg_PI+avg_DWL+wages, 
           share_CS=avg_CS/surplus,
           share_PS=avg_PS/surplus,
           share_PI=avg_PI/surplus,
           share_dwl=avg_DWL/surplus)%>%
    mutate(diff_sd_CS=(sd_CS-sd_CS[1])/sd_CS[1],
           diff_sd_PS=(sd_PS-sd_PS[1])/sd_PS[1],
           diff_sd_PI=(sd_PI -sd_PI[1])/sd_PI[1],
           diff_CS=(avg_CS-avg_CS[1])/avg_CS[1],
           diff_PS=(avg_PS-avg_PS[1])/avg_PS[1],
           diff_PI=(avg_PI-avg_PI[1])/avg_PI[1],
           diff_shortage=(shortage-shortage[1])/shortage[1])

price_avg30<-ggplot(price30)+
  geom_smooth(aes(omega, diff_CS*100, color="CS"), size=1.25)+
  geom_smooth(aes(omega, diff_PS*100, color="PS"), size=1.25)+
  geom_smooth(aes(omega, diff_PI*100, color="Processor Profit"), size=1.25)+
  ylab("% Changes in Surplus")+
  xlab("")+
  ylim(c(-100,100))+
  scale_x_reverse()+
  geom_hline(yintercept=0, lty="dashed")+
  scale_color_manual("", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue"))+
    theme_minimal()+
    theme(legend.position = 'top',
      legend.text =element_text(size=18))

price_sd30<-ggplot(price30)+
  geom_smooth(aes(omega, diff_sd_CS*100, color="CS"), size=1.25, se=F)+
  geom_smooth(aes(omega, diff_sd_PS*100, color="PS"), size=1.25, se=F)+
  geom_smooth(aes(omega, diff_sd_PI*100, color="Processor Profit"), size=1.25, se=F)+
  ylab("% Changes in the Coefficient of Variation")+
  xlab("")+
  ylim(c(-100,100))+
  scale_x_reverse()+
  geom_hline(yintercept=0, lty="dashed")+
  scale_color_manual("", values=c("PS"="orange","CS"="dark green", "Processor Profit"="dark blue"))+
  theme_minimal()+
  theme(legend.position = 'top',
          legend.text =element_text(size=18))

shortage30<-ggplot(price30)+theme_minimal()+geom_smooth(aes(omega, shortage, color="dark red"))+ylab("Shortage")+xlab("")+ylim(c(0,0.5))


#Make Figures

compete<-ggarrange(price_sd0, price_avg0, common.legend = TRUE, legend="top", nrow = 1)
annotate_figure(compete,
                bottom=text_grob((expression(omega))))
ggsave("Output/Figure7a.png", scale=5)

moderate<-ggarrange(price_sd15, price_avg15, common.legend = TRUE, legend="top", nrow = 1)
annotate_figure(moderate,
                bottom=text_grob((expression(omega))))
ggsave("Output/Figure7b.png", scale=5)

high<-ggarrange(price_sd30, price_avg30, common.legend = TRUE, legend="top", nrow = 1)
annotate_figure(high,
                bottom=text_grob((expression(omega))))
ggsave("Output/Figure7c.png", scale=5)


# Shortages of supply
shortage<-ggplot()+
    geom_line(aes(omega, shortage, lty="Competitive"), data=price0, size=1.25, color="steelblue4", se=F)+
    geom_line(aes(omega, shortage, lty="Moderate"), data=price15, size=1.25, color="steelblue4", se=F)+
    geom_line(aes(omega, shortage, lty="High"), data=price30, size=1.25, color="steelblue4", se=F)+
    scale_x_reverse()+
    ylab("Shortage")+
    xlab((expression(omega)))+
    theme_minimal()+
    scale_linetype_manual("Market Power",values=c("Competitive"="dashed","Moderate"="dotted","High"="solid"))+
    ylim(c(0,1))+
    theme_minimal()+
  theme(legend.position = "right",
        legend.key.size = unit(1, 'cm'))

ggsave("Output/Figure8.png", scale=5)
    
  